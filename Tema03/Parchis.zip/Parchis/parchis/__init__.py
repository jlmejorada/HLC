from parchis.Recursos import *
def main():
    parchis = Recursos("Juana","Pedro")
    print(Recursos.pinta_tablero(parchis))

if __name__ == "__main__":
    main()